"""
Vibrate
Microphone
Flashlight
Camera?
"""
